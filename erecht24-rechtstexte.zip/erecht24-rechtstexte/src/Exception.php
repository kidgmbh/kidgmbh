<?php
declare(strict_types=1);

namespace ERecht24;

use Exception as BaseException;

class Exception extends BaseException
{
    //
}